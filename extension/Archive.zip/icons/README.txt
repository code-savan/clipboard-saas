// This is a placeholder for the icon. In a real extension, you would create proper PNG files.
